# Project-2-Multi-Agent Search-UC-Berkeley-CS188-Intro-to-AI
Implementation of the 2nd Project: Multi-Agent Search from the Berkeley University

http://ai.berkeley.edu/multiagent.html

Implementation of Minimax - Aplha-beta Pruning - Expectimax - Evaluating Function using Python
